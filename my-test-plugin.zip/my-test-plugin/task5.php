<?php
/*
Функция добавления фильтра для ограничения товаров на странице магазина
*/
add_action('woocommerce_product_query', 'custom_limit_products_per_page');
function custom_limit_products_per_page($query) {
    if (is_shop() && !is_admin()) {
        $query->set('posts_per_page', 6);
    }
}

/*
Функция добавления пагинации для товаров
*/
add_action('woocommerce_after_shop_loop', 'custom_pagination', 10);
function custom_pagination() {
    global $wp_query;

    if ($wp_query->max_num_pages > 1) :
        echo '<div class="pagination woocommerce-pagination">';

        echo paginate_links(array(
            'format' => '?paged=%#%',
            'current' => max(1, get_query_var('paged')),
            'total' => $wp_query->max_num_pages,
        ));

        echo '</div>';
    endif;
}
?>


